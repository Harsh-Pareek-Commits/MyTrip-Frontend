import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-travels',
  templateUrl: './add-travels.component.html',
  styleUrls: ['./add-travels.component.css']
})
export class AddTravelsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
